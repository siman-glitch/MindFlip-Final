class Jugador {

    constructor(id, nombre, email, password, imagen) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.password = password;
        this.imagen = imagen;
    }

    getNombre() {
        return this.nombre;
    }

    cambiarNombre(nuevoNombre) {
        this.nombre = nuevoNombre;
    }

    cambiarEmail(nuevoEmail) {
        this.email = nuevoEmail;
    }

    cambiarImagen(nuevaImagen) {
        this.imagen = nuevaImagen;
    }
    cambiarPassword(nuevaPassword) {
    this.password = nuevaPassword;
}
    
}





class LocalStorage {

    // Guardar datos
    static guardar(clave, valor) {
        localStorage.setItem(clave, JSON.stringify(valor));
 }

    // Obtener datos
    static obtener(clave) {
        return JSON.parse(localStorage.getItem(clave));
    }

    // Eliminar datos
    static eliminar(clave) {
        localStorage.removeItem(clave);
    }

    // Obtener usuarios registrados
    static obtenerUsuarios() {
        return this.obtener("usuarios") || [];
    }

    // Guardar usuarios registrados
    static guardarUsuarios(usuarios) {
        this.guardar("usuarios", usuarios);
    }
}


class SesionStorage {

    // 1. Guardar datos en sessionStorage
    static guardar(clave, valor) {
        sessionStorage.setItem(clave, JSON.stringify(valor));
    }

    // 2. Obtener datos de sessionStorage
    static obtener(clave) {
        return JSON.parse(sessionStorage.getItem(clave));
    }

    // 3. Eliminar un dato de sessionStorage
    static eliminar(clave) {
        sessionStorage.removeItem(clave);
    }

    // 4. Borrar todos los datos de la sesión
    static limpiar() {
        sessionStorage.clear();
    }
}