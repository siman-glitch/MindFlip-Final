
/* ==========================================
   1. BOTÓN VER RANKING
========================================== */

// Buscar el boton de ver ranking en el HTML
let btnRanking = document.getElementById("btn_ranking");

// Cuando el usuario hace clic en el boton
btnRanking.addEventListener("click", function (evento) {

    // Evitar que el enlace haga su comportamiento normal
    evento.preventDefault();

    // Ir a la pagina de ranking
    window.location.href = "../ranking/ranking.html";
});


/* ==========================================
   2. BOTÓN VOLVER A JUGAR
========================================== */

// Buscar el boton de volver a jugar en el HTML
let btnJugar = document.getElementById("btn_jugar");

// Cuando el usuario hace clic en el boton
btnJugar.addEventListener("click", function (evento) {

    // Evitar que el enlace haga su comportamiento normal
    evento.preventDefault();

    // Ir a la pagina de dificultad para elegir nivel otra vez
    window.location.href = "../dificultad/dificultad.html";
});


/* ==========================================
   3. OBTENER DATOS DE LA PARTIDA
========================================== */

// Leer los datos que guardo el juego
let intentos = SesionStorage.obtener("intentos");
let segundos = SesionStorage.obtener("segundos");
let puntuacion=SesionStorage.obtener("puntuacion");
/* ==========================================
   4. MOSTRAR RESULTADO
========================================== */

// Si no hay datos (se entro directo a esta pagina), volver a elegir nivel
if (intentos === null) {

    window.location.href = "../dificultad/dificultad.html";

} else {

    // Pasar los segundos a formato 00:00
    let minutos = String(Math.floor(segundos / 60)).padStart(2, "0");
    let segundosRestantes = String(segundos % 60).padStart(2, "0");

    // Rellenar los datos en la pagina
    document.getElementById("resultado_tiempo").textContent = minutos + ":" + segundosRestantes;

    document.getElementById("resultado_intentos").textContent = intentos;
    document.getElementById("resultado_puntuacion").textContent = puntuacion;

}
