
/* ==========================================
   1. ELEMENTOS DEL HTML
========================================== */

//creamos variables para guardar estos elementos del html 
//Utilizamos document.getElementById() para buscar elementos del HTML por su ID y guardarlos en variables
//para despues poder llamarlos con el nombre de la variable
let tablaCuerpo = document.getElementById("filas_ranking");
let btnResetear = document.getElementById("btn_resetear");


/* ==========================================
   2. DATOS DE LA PARTIDA ACTUAL
========================================== */

//usuario_logueado es el dato que guardamos en inicio.js
let jugadorActivo = SesionStorage.obtener("usuario_logueado");
let puntosPartida = SesionStorage.obtener("puntuacion");

// NUEVO: id del jugador que ha iniciado sesion (lo guarda inicio.js)
let idActivo = SesionStorage.obtener("usuario_id");


/* ==========================================
   3. LEER EL RANKING GUARDADO
========================================== */
//kanjibo ranking mn localstorage (guardarpartida)
function leerRanking() {
 // Obtener de LocalStorage el ranking guardado con la clave "ranking_historico"
    let lista = LocalStorage.obtener("ranking_historico");

    // Comprobar si no existe ningún ranking guardado
    if (lista === null) {
        // Devolver un array vacío si todavía no hay ningún ranking
        return [];
    }
    return lista;
}


/* ==========================================
   4. FECHA Y HORA ACTUAL (dd/mm/aaaa hh:mm)
========================================== */

function fechaActual() {
    //obtiene la fecha y la hora actuales
    let ahora = new Date();

    // Obtener el día del mes y añadir un cero delante si solo tiene una cifra
    let dia = String(ahora.getDate()).padStart(2, "0");
    let mes = String(ahora.getMonth() + 1).padStart(2, "0");
    // Obtener la hora actual y añadir un cero delante si solo tiene una cifra
    let hora = String(ahora.getHours()).padStart(2, "0");
    // Obtener los minutos actuales y añadir un cero delante si solo tiene una cifra
    let minutos = String(ahora.getMinutes()).padStart(2, "0");

    return dia + "/" + mes + "/" + ahora.getFullYear() + " " + hora + ":" + minutos;
}


/* ==========================================
   5. GUARDAR LA PARTIDA EN EL RANKING
========================================== */

function guardarPartida() {


    // Si no viene de una partida, no hay nada que guardar
    //ila ma3dnach jugador o maendoch puntuacion makandiro walu
    if (jugadorActivo === null || puntosPartida === null) {
        return;
    }

    //kanjibo ranking guardado en localstorage
    //ranking[]
    let ranking = leerRanking();//el resultado de leer ranking se alamcena en variable ranking

    // Buscar si este jugador ya esta en el ranking (por su id)
    let encontrado = false;

    for (let i = 0; i < ranking.length; i++) { //mientras i sea menor que la cantidad de jugadors, i++

        if (ranking[i].id === idActivo) { // si el id del jugador que estoy revisando en el ranking , es igual al que esta jugando actualmente

            encontrado = true;// indicamos que hemos encontrado al jugador

            // Actualizar siempre con los datos de la ultima partida
            ranking[i].puntuacion = puntosPartida;
            ranking[i].fecha = fechaActual();

            // Por si ha cambiado de nombre en el perfil
            ranking[i].jugador = jugadorActivo;

            break; // detiene el bucle for
        }
    }

    // Si no estaba, anadirlo como jugador nuevo
    if (!encontrado) {
        ranking.push({ //push añade un elemento nuevo al final del array
            id: idActivo,
            jugador: jugadorActivo,
            puntuacion: puntosPartida,
            fecha: fechaActual()
        });
    }

    // Ordenar de mayor a menor y quedarse con los 10 mejores
    ranking.sort(function (a, b) {
        return b.puntuacion - a.puntuacion; //compara puntuaciones de 2 jugadores
    });
    ranking = ranking.slice(0, 10); //nos quedamos con los primeros 10 elementos del array

    LocalStorage.guardar("ranking_historico", ranking);
}

/* ==========================================
   6. BUSCAR UN USUARIO POR SU ID
========================================== */

// NUEVO: igual que cargarPerfil en perfil.js
function buscarUsuario(id) {

    let usuarios = LocalStorage.obtenerUsuarios();
    
    //usuarios.lenght nos dice cuantos usuarios tenemos
    //Mientras i sea menor que la cantidad de usuarios, el bucle continúa.
    for (let i = 0; i < usuarios.length; i++) { // recorremos usuarios
        if (usuarios[i].id === id) {
            return usuarios[i];
        }
    }

    // Si no lo encuentra
    return null;
}


/* ==========================================
   7. MOSTRAR EL RANKING
========================================== */


function mostrarRanking() {

    // Obtener el ranking guardado
    let ranking = leerRanking();

    // Medallas para los tres primeros jugadores
    let medallas = ["🥇 ", "🥈 ", "🥉 "]; // creamos un array

    // Vaciar la tabla antes de mostrar los jugadores
    tablaCuerpo.innerHTML = ""; //innerhtml permite modificar el contido html de un elemento 

    // Si el ranking está vacío, mostrar un mensaje
    if (ranking.length === 0) {// comprobamos si el array rankin tiene 0 jugadores
        
        tablaCuerpo.innerHTML = "<tr><td colspan='5'>No hay puntuaciones</td></tr>";
        //tr crea una fila,td crea una celda,colspan='5' hace que esa celda ocupe el espacio de 5 columnas.
        return;
    }

    // Recorrer todos los jugadores del ranking
    ranking.forEach(function(partida, index) { //partida son los elemntos del jugador id nombre fecha,etc.
    //index posicion, del array del objeto,0,1,2,etc


        // Obtener la posición del jugador
        let posicion = index + 1;

        // Obtener el nombre del jugador
        let nombre = partida.jugador;

        // Añadir medallas a los tres primeros
        if (index < 3) { //si el jugador esta entre los primeros 3
            nombre = medallas[index] + nombre; //junta la medalla con el nombre del jugadores
        }

        // Buscar los datos del usuario por su ID
        let usuario = buscarUsuario(partida.id);

        // Crear una variable para la foto
        let foto = "";

        // Si el usuario tiene foto, mostrarla
        if (usuario !== null && usuario.imagen) {// comporbamos que usuario no sea null
            foto = `<img src="${usuario.imagen}" alt="Foto">`;// si se cumple ambas condiciones, creamos una etiqueta img con la ruta de su fotografia
        }

        // Crear una nueva fila en la tabla
        let fila = document.createElement("tr");

        // Añadir los datos del jugador a la fila
        fila.innerHTML = `
            <td>${posicion}</td>
            <td><div class="avatar_ranking">${foto}</div></td>
            <td>${nombre}</td>
            <td>${partida.puntuacion}</td>
            <td>${partida.fecha}</td>
        `;

        // Añadir la fila a la tabla HTML
        tablaCuerpo.appendChild(fila);//añade la fila que hemos creado
    });
}



/* ==========================================
   8. BOTON RESETEAR
========================================== */




btnResetear.addEventListener("click", function () {

    if (confirm("¿Seguro que quieres borrar todo el ranking?")) {
        LocalStorage.eliminar("ranking_historico");
        mostrarRanking();
    }
});


/* ==========================================
   9. EJECUTAR AL CARGAR LA PAGINA
========================================== */

guardarPartida();
mostrarRanking();
