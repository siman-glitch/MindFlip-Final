
/* ==========================
   1. IMAGENES Y VARIABLES
========================== */

// Imagen de la parte de atras de las cartas
const imagenReverso = "../recursos/imagenes/carta_reverso.png";

// Todas las imagenes del juego
const cartas = [
    "../recursos/imagenes/01_simple_corazon.png",
    "../recursos/imagenes/02_simple_pica.png",
    "../recursos/imagenes/03_simple_diamante.png",
    "../recursos/imagenes/04_simple_trebol.png",
    "../recursos/imagenes/05_doble_corazon.png",
    "../recursos/imagenes/06_doble_pica.png",
    "../recursos/imagenes/07_doble_diamante.png",
    "../recursos/imagenes/08_doble_trebol.png",
    "../recursos/imagenes/09_as_corazon.png",
    "../recursos/imagenes/10_as_pica.png",
    "../recursos/imagenes/11_as_diamante.png",
    "../recursos/imagenes/12_as_trebol.png"
];

// Guarda las dos cartas elegidas por el usuario
let cartasSeleccionadas = [];

// Numero de parejas correctas
let parejasEncontradas = 0;

// Parejas que hay que encontrar para ganar
let totalParejas = 0;

// Contar los intentos
let intentos = 0;

// Segundos que lleva la partida
let segundos = 0;

// Guarda el reloj para poder pararlo al ganar
let cronometro;


/* ==========================
   2. OBTENER DIFICULTAD
========================== */

function getNivelElegido() {

    // Leer el nivel guardado en sessionStorage
    let nivelElegido = SesionStorage.obtener("dificultad_juego");

    return nivelElegido;
}


/* ==========================
   3. NUMERO DE PAREJAS
========================== */

function numeroCartas(nivelElegido) {

    // Facil: 6 parejas = 12 cartas
    if (nivelElegido === "facil") {
        return 6;

        // Medio: 8 parejas = 16 cartas
    } else if (nivelElegido === "medio") {
        return 8;

        // Dificil: 12 parejas = 24 cartas
    } else if (nivelElegido === "dificil") {
        return 12;
    }
}


/* ==========================
   4. PREPARAR LAS CARTAS
========================== */

function crearCartas(nivelElegido) {

    // Obtener el numero de parejas del nivel
    let numCartas = numeroCartas(nivelElegido);

    // Elegir las imagenes necesarias
    let cartasElegidas = cartas.slice(0, numCartas);

    // Duplicar las imagenes para formar parejas
    let imgDuplicadas = cartasElegidas.concat(cartasElegidas);

    // Mezclar las cartas de forma sencilla
    imgDuplicadas.sort(() => Math.random() - 0.5);

    // Devolver las cartas mezcladas
    return imgDuplicadas;
}


/* ==========================
   5. MOSTRAR LAS CARTAS
========================== */

function mostrarCartas(cartasJuego) {

    // Buscar el tablero en HTML
    let tabla = document.getElementById("tablero");

    // Vaciar el tablero
    tabla.innerHTML = "";

    // Recorrer todas las cartas
    cartasJuego.forEach(nombreImagen => {

        // Crear un boton para cada carta
        let btnCarta = document.createElement("button");

        // Crear una imagen dentro del boton
        let imgReversoPosition = document.createElement("img");

        // Mostrar primero la parte de atras
        imgReversoPosition.src = imagenReverso;

        // Meter la imagen dentro del boton
        btnCarta.appendChild(imgReversoPosition);

        // Meter el boton dentro del tablero
        tabla.appendChild(btnCarta);

        // Preparar el clic de esta carta
        Voltearcarta(btnCarta, imgReversoPosition, nombreImagen);
    });
}


/* ==========================
   6. VOLTEAR UNA CARTA
========================== */

function Voltearcarta(btnCarta, imagenRevrso, carta) {

    // Cuando el usuario hace clic en una carta
    btnCarta.addEventListener("click", function () {

        // Si ya hay dos cartas elegidas, no aceptar otra
        if (cartasSeleccionadas.length === 2) {
            return;
        }

        // Bloquear esta carta para evitar dos clics
        btnCarta.disabled = true;

        // Mostrar la imagen verdadera
        imagenRevrso.src = carta;

        // Guardar los datos de la carta seleccionada
        cartasSeleccionadas.push({

            // Ruta de la imagen para comparar
            carta: carta,

            // Elemento HTML img
            imagen: imagenRevrso,

            // Boton para bloquearlo o desbloquearlo
            boton: btnCarta
        });

        // Cuando hay dos cartas, compararlas
        if (cartasSeleccionadas.length === 2) {
            CompararParejas();
        }
    });
}


/* ==========================
   7. COMPARAR PAREJAS
========================== */

function CompararParejas() {

    // Obtener la primera carta del array
    let primeraCarta = cartasSeleccionadas[0];

    // Obtener la segunda carta del array
    let segundaCarta = cartasSeleccionadas[1];

    // Un intento = comparar dos cartas
    intentos++;

    // Mostrar los intentos
    document.getElementById("intentos").textContent = intentos;

    // Comprobar si las dos imagenes son iguales
    if (primeraCarta.carta === segundaCarta.carta) {

        // Sumar una pareja correcta
        parejasEncontradas++;

        // Mostrar las parejas encontradas
        document.getElementById("parejas_encontradas").textContent = parejasEncontradas;

        // Las cartas iguales se quedan descubiertas

        // Vaciar el array para elegir otra pareja
        cartasSeleccionadas = [];

        // Comprobar si hemos ganado
        if (parejasEncontradas === totalParejas) {

            // Parar el cronometro
            clearInterval(cronometro);

            // Guardar los datos para resultado
            SesionStorage.guardar("intentos", intentos);
            SesionStorage.guardar("segundos", segundos);

            // Calcular y guardar la puntuacion
            let puntuacion = calcularPuntuacion();
            SesionStorage.guardar("puntuacion", puntuacion);

            // Esperar un momento y pasar a resultado
            setTimeout(function () {
                window.location.href = "../resultado/result.html";
            }, 800);
        }

    } else {

        // Si son diferentes, esperar un segundo
        setTimeout(function () {

            // Volver a mostrar el reverso
            primeraCarta.imagen.src = imagenReverso;
            segundaCarta.imagen.src = imagenReverso;

            // Permitir volver a pulsar estas cartas
            primeraCarta.boton.disabled = false;
            segundaCarta.boton.disabled = false;

            // Vaciar el array
            cartasSeleccionadas = [];

        }, 1000);
    }

    // Actualizar la puntuacion despues de comparar
    document.getElementById("puntuacion").textContent = calcularPuntuacion();
}


/* ==========================
   8. INICIAR EL JUEGO
========================== */

function jugar() {

    // Obtener la dificultad elegida
    let nivel = getNivelElegido();

    // Guardar cuantas parejas hay que encontrar
    totalParejas = numeroCartas(nivel);

    // Crear las parejas y mezclar las cartas
    let cartasJuego = crearCartas(nivel);

    // Mostrar todas las cartas en el tablero
    mostrarCartas(cartasJuego);

    // Iniciar el cronometro
    iniciarCronometro();

    // Mostrar la puntuacion inicial
    document.getElementById("puntuacion").textContent = 1000;

    // Contar las partidas en sesion
    contarPartidasSesion();
}


/* ==========================
   9. ESTADISTICAS
========================== */

/*============ NIVEL ACTUAL =============*/

let nivelElegido = getNivelElegido();

let nivelacutal = document.getElementById("nivel_actual");

nivelacutal.textContent = nivelElegido;


/*============ TIEMPO =============*/

function iniciarCronometro() {

    // Buscar el elemento HTML
    let tiempo = document.getElementById("tiempo");

    // Repetir cada segundo
    cronometro = setInterval(function () {

        // Sumar un segundo
        segundos++;

        // Convertir segundos a minutos
        let minutos = Math.floor(segundos / 60);

        // Obtener los segundos restantes
        let segundosRestantes = segundos % 60;

        // Añadir un cero delante
        let minutosTexto = String(minutos).padStart(2, "0");
        let segundosTexto = String(segundosRestantes).padStart(2, "0");

        // Mostrar el tiempo
        tiempo.textContent = minutosTexto + ":" + segundosTexto;

    }, 1000);
}


/*============ PUNTUACION =============*/

function calcularPuntuacion() {

    // Calcular los intentos fallidos
    let fallos = intentos - parejasEncontradas;

    // Empezamos con 1000 puntos
    let puntuacion = 1000 - fallos * 50;

    // Si la puntuacion es negativa, dejarla en 0
    if (puntuacion < 0) {
        puntuacion = 0;
    }

    // Devolver la puntuacion
    return puntuacion;
}


/*============ PARTIDAS EN SESION =============*/

function contarPartidasSesion() {

    // Obtener las partidas guardadas
    let partidas = SesionStorage.obtener("partidas_sesion");

    // Si no hay partidas, empezar desde cero
    if (partidas === null) {
        partidas = 0;
    }

    // Sumar una partida
    partidas++;

    // Guardar las partidas
    SesionStorage.guardar("partidas_sesion", partidas);

    // Mostrar las partidas en HTML
    document.getElementById("partidas_sesion").textContent = partidas;
}
/*============ BUTTON REINICIAR=============*/

let btnReiniciar = document.getElementById("reiniciar_partida");

btnReiniciar.addEventListener("click", function () {

    // 1. Parar el cronometro anterior
    clearInterval(cronometro);


    // 2. Reiniciar las variables
    intentos = 0;
    segundos = 0;
    parejasEncontradas = 0;
    cartasSeleccionadas = [];


        // 3. Mostrar los valores iniciales en HTML
    document.getElementById("intentos").textContent = 0;
    document.getElementById("tiempo").textContent = "00:00";
    document.getElementById("parejas_encontradas").textContent = 0;
    document.getElementById("puntuacion").textContent = 1000;

        // 4. Empezar una partida nueva
    jugar();

});
/* ==========================
   10. INICIAR EL JUEGO
========================== */

// Iniciar el juego
jugar();
